# Updated scores for a different scenario
exam_results = [78, 90, 82, 78, 88, 90, 78, 82, 78, 90, 82, 78, 88, 90, 82, 78, 82, 90]

# Calculate the frequency of the score 82
frequency_82 = exam_results.count(82)

print("Frequency of the score 82:", frequency_82)
